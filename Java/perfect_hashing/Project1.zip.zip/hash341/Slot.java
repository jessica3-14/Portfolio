package hash341;

import java.io.Serializable;

public class Slot implements Serializable {
    public int nCity;
    public int nHash;
    public Slot(){
        nCity=0;
        nHash=0;
    }
    public void add(City c){

    }
    public String toString() {
        // TODO Auto-generated method stub
        return "";
    }
    
}
